<a href="{{ route($url) }}" class="btn btn-secondary float-md-end ms-1" style="height: 45px; padding-top: 10px;">{{ $btnText }}</a>

