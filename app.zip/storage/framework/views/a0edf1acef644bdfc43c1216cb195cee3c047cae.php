

<?php $__env->startSection('title', 'Cashiers'); ?>

<?php $__env->startSection('content'); ?>

<div class="row mt-5">
  <div class="col-md-8 col-lg-12">
    <?php if(session('created') || session('deleted') || session('resetted-password')): ?>
    <div class="alert alert-success alert-dismissible fade show mt-4" role="alert">
        <strong>Great!</strong> <?php echo e(session('message')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <div class="row">
      <div class="col-md-6">
        <h3 class="mt-2"><i data-feather="align-left"></i> List of User Accounts</h3>
      </div>
      <div class="col-md-6">
        <a class="btn btn-primary mb-3 pb-2 pt-2 mt-2 float-end" href="<?php echo e(route('admin.users.create')); ?>"><i data-feather="user-plus" class="feather-20 mx-1 pb-1 pt-1"></i> Register new</a>
      </div>
    </div>
    <div class="card">
      <div class="table-responsive mb-0">
        <table class="table mb-0">
            <thead>       
              <tr>
                <td scope="col" class="border-bottom-0 border-top-0 p-3"><strong>FULL NAME</strong></td>
                <td scope="col" class="border-bottom-0 border-top-0  p-3"><strong>USERNAME</strong></td>
                <td scope="col" class="border-bottom-0 border-top-0  p-3"><strong>ROLE</strong></td>
                <td scope="col" class="border-bottom-0 border-top-0  p-3"><strong>ACTIONS</strong></td>
              </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td scope="row" class="p-3 border-bottom-0 border-top"><?php echo e($user->name); ?></td>
                  <td class="p-3 border-bottom-0 border-top"><?php echo e($user->username); ?></td>
                  <td class="p-3 border-bottom-0 border-top"><?php echo e($user->user_role()); ?></td>
                  <td class="border-bottom-0 border-top py-2">
                    <div class="d-flex justify-content-start pe-0 my-1 me-0">
                      <a href="<?php echo e(route('admin.users.edit',$user)); ?>" class="me-1 bg-warning py-1 px-2 rounded-1 text-white text-decoration-none">Edit</a>
                      <form action="<?php echo e(route('admin.users.destroy',$user)); ?>" method="post" class="pt-0 mb-0">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                        <button type="submit" class="bg-danger py-1 px-2 rounded-1 text-white text-decoration-none border-0 mx-1" onclick="return confirm('Are you sure you want to delete this user? This cannot be reverted back.')">Delete</button>
                      </form>
                      <form action="<?php echo e(route('admin.user-passwords.update',$user)); ?>" method="post" class="pt-0 mb-0">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <button type="submit" class="btn-secondary border-0 py-1 px-2 rounded-1 text-white text-decoration-none mx-1">Reset Password</a>
                      </form>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="4" class="text-center border-top border-bottom-0">No records yet!</td>
                </tr>
                <?php endif; ?>
            </tbody>
          </table>
        
      </div>
    
    </div>
    <?php echo e($users->links()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/macroho1/public_html/resources/views/pages/users/index.blade.php ENDPATH**/ ?>