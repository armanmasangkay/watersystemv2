

<?php $__env->startSection('title', 'Service Lists'); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-12 mt-4">
        <div class="row justify-content-between">
            <div class="col-md-3 py-0">
                <h5 class="text-secondary h4 mt-4 mb-3"><i data-feather="align-right" class="mb-1 feather-30 me-1"></i> Lists of Services</h5>
            </div>
            <div class="col-md-7 pt-md-3">
                <form action="<?php echo e(route('admin.services.filter')); ?>" class="d-flex justify-content-start mb-2" method="get">
                    <label class="me-2">From</label>
                    <input type="date" class="form-control me-2 <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="from" value="<?php echo e($from??session('from')); ?>"/>
                    <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label class="me-2">To</label>
                    <input type="date" class="form-control me-2 <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="to" value="<?php echo e($to??session('to')); ?>"/>
                    <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <select class="form-select me-1" name="filter" id="filter">
                        <option value="none">None</option>
                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(request()->filter == $key): ?>
                                <option value="<?php echo e($key); ?>" selected><?php echo e($value); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button type="submit" class="d-flex items-center pt-2 btn btn-primary"><i data-feather="filter" class="feather-18 me-2 mt-1"></i> <span class="mt-1">Filter</span></button>
                </form>
            </div>
        </div>
        <div class="card">
            <div class="table-responsive mb-0">
                <table class="table mb-0">
                    <thead>
                        <tr>
                            <td scope="col" class="border-bottom-0 border-top-0 py-3"><strong>REQUEST NUMBER</strong></td>
                            <td scope="col" class="border-bottom-0 border-top-0 py-3"><strong>FULL NAME</strong></td>
                            <td scope="col" class="border-bottom-0 border-top-0 py-3"><strong>TYPE OF SERVICE</strong></td>
                            <td scope="col" class="border-bottom-0 border-top-0 py-3"><strong>REMARKS</strong></td>
                            <td scope="col" class="border-bottom-0 border-top-0 py-3"><strong>LANDMARKS</strong></td>
                            <td scope="col" class="border-bottom-0 border-top-0 py-3"><strong>CONTACT NUMBER</strong></td>
                            <td scope="col" class="border-bottom-0 border-top-0 py-3"><strong>STATUS</strong></td>
                            <td scope="col" class="border-bottom-0 border-top-0 py-3"><strong>ACTION</strong></td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td scope="row" class="py-3 border-bottom-0 border-top"><?php echo e($service->request_number); ?></td>
                                <td scope="row" class="py-3 border-bottom-0 border-top"><?php echo e($service->customer->fullname()); ?></td>
                                <td scope="row" class="py-3 border-bottom-0 border-top"><?php echo e($service->prettyType()); ?></td>
                                <td scope="row" class="py-3 border-bottom-0 border-top"><?php echo e($service->remarks); ?></td>
                                <td scope="row" class="py-3 border-bottom-0 border-top"><?php echo e($service->landmarks); ?></td>
                                <td scope="row" class="py-3 border-bottom-0 border-top"><?php echo e($service->customer->contact_number); ?></td>
                                <td scope="row" class="py-3 border-bottom-0 border-top"><?php echo e($service->prettyStatus()); ?></td>
                                <td scope="row" class="py-3 border-bottom-0 border-top">
                                    <div class="row">
                                        <?php if($service->isReady()): ?>
                                        <div class="col-6 pe-0">
                                            <a href="<?php echo e(route('admin.workorder.filter', ['request_number' => $service->request_number])); ?>" class="text-center">Print</a>
                                        </div>
                                        <?php endif; ?>
                                        <div class="col-6 ps-0 pt-0">
                                            <form action="<?php echo e(route("admin.services.destroy",$service)); ?>" method="post" class="mb-0 pt-0">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field("DELETE"); ?>
                                                <button type="submit" class="btn-link text-danger border-0 bg-white ps-0 float-start" 
                                                        onclick="return confirm('Are you sure you want to delete this? You cannot undo this action')">
                                                        Delete
                                                </button>
                                            </form>
                                        </div>
                                    </div>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="text-center border-top border-bottom-0">No records yet!</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <?php echo e($services->render()); ?>

            </div>
            <div class="col-md-6">
                <?php if(request()->filter == "finished" && count($services) > 0): ?>
                <a href="<?php echo e(route('admin.workorder')); ?>" class="btn btn-secondary btn-lg rounded-sm float-end mt-2"><i data-feather="printer" class="feather-18 mb-1 me-1"></i> Print WOR</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/macroho1/public_html/resources/views/pages/services-list.blade.php ENDPATH**/ ?>