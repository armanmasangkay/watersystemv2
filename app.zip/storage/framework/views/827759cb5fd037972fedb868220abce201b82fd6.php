<form action="<?php echo e(route($search_route)); ?>" method="get" class="mt-2 mb-2 form-inline">
    <?php if(Request::is('admin/consumer-ledger*')): ?>
    <input type="text" name="account_number" class="w-25 rounded bg-white border pt-2 pb-2 px-2
    <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="" value="<?php echo e(old('account_number',request()->account_number??'')); ?>"
    placeholder="Account number" required>
    <?php else: ?>
    <input type="text" name="keyword" class="<?php echo e(Request::is('admin/water-works/request-approvals*') || Request::is('admin/bldg-area/request-approvals*') ? 'w-50' : 'w-25'); ?> rounded bg-white border pt-2 pb-2 px-2
    <?php $__errorArgs = ['keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="" value="<?php echo e(old('keyword',request()->keyword??'')); ?>"
    placeholder="Account number / Name" required>
    <?php endif; ?>
    <button href="" class="btn btn-primary ms-1">
    <i data-feather="search" width="20"></i>
    Search</button>

    <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback">
        <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</form>


<?php /**PATH /home/macroho1/public_html/resources/views/templates/form-search-account.blade.php ENDPATH**/ ?>