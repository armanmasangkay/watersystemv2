

<?php $__env->startSection('title', 'Work Order Payments'); ?>


<?php $__env->startSection('content'); ?>

<?php if($payments->count()>0): ?>
<h4 class="mt-4 text-center">(Work Order Payments)</h4>
<div class="table-responsive">
  <table class="table table-striped mt-4 table-bordered">
      <thead>
          <th>Service Name</th>
          <th>Transacted To </th>
          <th>OR #</th>
          <th>Paid</th>
          <th>Paid on</th>
        </thead>
        <tbody>
        
            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($payment->service->prettyServiceType()); ?></td>
                  <td><?php echo e($payment->customer_id); ?></td>
                  <td><?php echo e($payment->or_no); ?></td>
                  <td><?php echo e($payment->prettyPaymentAmount()); ?></td>
                  <td><?php echo e($payment->created_at); ?></td>

              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
  </table>
</div>
<?php else: ?>
<div class="mt-4">
  <p class="text-center text-muted">No payments to show!</p>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/macroho1/public_html/resources/views/pages/work-order-payments.blade.php ENDPATH**/ ?>