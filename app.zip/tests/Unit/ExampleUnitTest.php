<?php

namespace Tests\Unit;

use App\Models\Customer;
use App\Models\Service;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use PHPUnit\Framework\TestCase;

class ExampleUnitTest extends TestCase
{
    
    public function test_example()
    {
        $this->assertTrue(true);
    }

}
